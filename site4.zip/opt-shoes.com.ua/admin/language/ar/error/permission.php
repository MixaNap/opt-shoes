<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'صلاحيات محدودة !'; 

// Text
$_['text_permission'] = 'انت لا تمتلك صلاحية لدخول هذه الصفحة - الرجاء ابلاغ المدير.';
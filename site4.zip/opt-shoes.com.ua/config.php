<?php
// HTTP
define('HTTP_SERVER', 'https://opt-shoes.com.ua/');

// HTTPS
define('HTTPS_SERVER', 'https://opt-shoes.com.ua/');

// DIR
define('DIR_APPLICATION', '/var/www/optsho01/data/www/opt-shoes.com.ua/catalog/');
define('DIR_SYSTEM', '/var/www/optsho01/data/www/opt-shoes.com.ua/system/');
define('DIR_IMAGE', '/var/www/optsho01/data/www/opt-shoes.com.ua/image/');
define('DIR_STORAGE', '/var/www/optsho01/data/www/storage/');
define('DIR_LANGUAGE', DIR_APPLICATION . 'language/');
define('DIR_TEMPLATE', DIR_APPLICATION . 'view/theme/');
define('DIR_CONFIG', DIR_SYSTEM . 'config/');
define('DIR_CACHE', DIR_STORAGE . 'cache/');
define('DIR_DOWNLOAD', DIR_STORAGE . 'download/');
define('DIR_LOGS', DIR_STORAGE . 'logs/');
define('DIR_MODIFICATION', DIR_STORAGE . 'modification/');
define('DIR_SESSION', DIR_STORAGE . 'session/');
define('DIR_UPLOAD', DIR_STORAGE . 'upload/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'evelina');
define('DB_PASSWORD', '5yicRN75HBHA9Jh');
define('DB_DATABASE', 'opt0shose');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');